#include "kd_tree.h"

double kdNode::LB(double*q,int dim,statistics& stat)
{
	double ub;
	double L;

	ub = u_MBR(q, boundary, dim);
	if (stat.kernel_type == 0) //Gaussian kernel
		L = sum_alpha * exp(-stat.gamma*ub*ub);
	if (stat.kernel_type == 1) //Triangular kernel
		L = sum_alpha * max(1 - stat.gamma*ub, 0.0);
	if (stat.kernel_type == 2) //Cosine kernel
	{
		if (ub <= stat.gamma)
			L = sum_alpha * cos(pi * ub / (2 * stat.gamma));
		else
			L = 0;
	}
	if (stat.kernel_type == 3) //Exponential kernel
		L = sum_alpha * exp(-stat.gamma*ub);

	return L;
}

double kdNode::UB(double*q,int dim,statistics& stat)
{
	double lb;
	double U;

	lb = ell_MBR(q, boundary, dim);

	if (stat.kernel_type == 0) //Gaussian kernel
		U = sum_alpha * exp(-stat.gamma*lb*lb);
	if (stat.kernel_type == 1) //Triangular kernel
		U = sum_alpha * max(1 - stat.gamma*lb, 0.0);
	if (stat.kernel_type == 2) //Cosine kernel
	{
		if (lb <= stat.gamma)
			U = sum_alpha * cos(pi * lb / (2 * stat.gamma));
		else
			U = 0;
	}
	if (stat.kernel_type == 3) //Exponential kernel
		U = sum_alpha * exp(-stat.gamma*lb);

	return U;
}

kdNode*kdNode::createNode()
{
	return new kdNode();
}

//kdLinearAugNode
double kdLinearAugNode::LB(double*q,int dim,statistics& stat)
{
	double t_star;
	double ip=0;

	if (stat.kernel_type == 0) //Gaussian kernel
	{
		for (int d = 0; d < dim; d++)
			ip = ip + q[d] * a_G[d];

		//Compute t^*
		gamma_sum = stat.gamma*(sum_alpha*stat.qSquareNorm - 2 * ip + S_G);
		t_star = (gamma_sum / sum_alpha);
		return sum_alpha * exp(-t_star);
	}

	if (stat.kernel_type >= 1 && stat.kernel_type <= 3)
	{
		cout << "This bound is not applicable to this kernel function!" << endl;
		exit(0);
	}

	return 0;
}

double kdLinearAugNode::UB(double*q,int dim,statistics& stat)
{
	double lb,ub;
	double l2,u2;
	double exp_l2,exp_u2;
	double m,c;

	//use MBR
	if (stat.kernel_type == 0) //Gaussian kernel
	{
		lb = ell_MBR(q, boundary, dim);
		ub = u_MBR(q, boundary, dim);

		l2 = lb * lb;
		u2 = ub * ub;

		//l2=u2, we cannot use mx+c to act as upper bound computationally
		if (u2 - l2 < stat.epsilon)
			return sum_alpha * exp(-stat.gamma*l2);

		exp_l2 = exp(-stat.gamma*l2);
		exp_u2 = exp(-stat.gamma*u2);
		//compute m and c
		m = (exp_u2 - exp_l2) / (stat.gamma*(u2 - l2));
		c = (u2*exp_l2 - l2 * exp_u2) / (u2 - l2);

		return (m*gamma_sum + c * sum_alpha);
	}

	if (stat.kernel_type >= 1 && stat.kernel_type <= 3)
	{
		cout << "This bound is not applicable to this kernel function!" << endl;
		exit(0);
	}

	return 0;
}

kdLinearAugNode*kdLinearAugNode::createNode()
{
	return new kdLinearAugNode();
}

void kdLinearAugNode::update_Aug(Node*node,Tree*t)
{
	//this->updateAugInfo((kdLinearAugNode*)node,t);
	this->update_linearAugInfo((kdLinearAugNode*)node,t);
}

void kdLinearAugNode::update_linearAugInfo(kdLinearAugNode*node,Tree*t)
{
	int id;
	double norm_square;
	//obtain vec a_G
	node->a_G=new double[t->dim];
	node->a_G_avg = new double[t->dim];

	for (int d = 0; d < t->dim; d++)
		node->a_G[d] = 0;

	//We relate center and a_G in this way
	for (int i = 0; i < (int)node->idList.size(); i++)
	{
		id = node->idList[i];
		for (int d = 0; d < t->dim; d++)
			node->a_G[d] += t->alphaArray[id] * t->dataMatrix[id][d];
	}

	//obtain S_G
	node->S_G=0;
	for(int i=0;i<(int)node->idList.size();i++)
	{
		id=node->idList[i];
		norm_square=0;
		for(int d=0;d<t->dim;d++)
			norm_square=norm_square+t->dataMatrix[id][d]*t->dataMatrix[id][d];

		node->S_G+=t->alphaArray[id]*norm_square;
	}

	//used in visualization
	node->a_G_avg_sq = 0;
	for (int d = 0; d < t->dim; d++)
	{
		node->a_G_avg[d] = node->a_G[d] / node->sum_alpha;
		node->a_G_avg_sq += node->a_G_avg[d] * node->a_G_avg[d];
	}
	node->b_G_avg = node->S_G / node->sum_alpha;

	if((int)node->idList.size()<=t->leafCapacity) //this is the leaf node
		return;

	update_linearAugInfo((kdLinearAugNode*)node->childVector[0],t);
	update_linearAugInfo((kdLinearAugNode*)node->childVector[1],t);
}

//kdQuadAugNode
double kdQuadAugNode::LB(double*q, int dim, statistics& stat)
{
	double t_star;
	double ip_aG = 0;
	double ip_vG = 0;
	double m_ell,k_ell;
	double x_max;
	double ub;
	double exp_minus_t_star;
	double a, b, c; //coefficients of quadratic function
	double quadratic_form = 0;

	if (stat.kernel_type == 0) //Gaussian kernel
	{
		for (int d = 0; d < dim; d++)
		{
			ip_aG += q[d] * a_G[d];
			ip_vG += q[d] * v_G[d];
		}

		//Compute t^*
		gamma_sum = stat.gamma*(sum_alpha*stat.qSquareNorm - 2 * ip_aG + S_G);
		t_star = (gamma_sum / sum_alpha);

		//Compute slope and intercept of line
		ub = u_MBR(q, boundary, dim);
		x_max = stat.gamma*ub*ub;
		exp_minus_t_star = exp(-t_star);
		m_ell = -exp_minus_t_star;
		k_ell = (1 + t_star)*exp_minus_t_star;

		//Degeneration case
		if (x_max - t_star < stat.epsilon)
			return sum_alpha * exp(-x_max);

		//obtain the coefficients of quadratic function
		a = (exp(-x_max) - k_ell - m_ell * x_max) / ((x_max - t_star)*(x_max - t_star));
		b = m_ell - 2 * a*t_star;
		c = a * t_star*t_star + k_ell;

		//Compute Quadratic form q^TCq
		for (int d1 = 0; d1 < dim; d1++)
		{
			temp_quad_vector[d1] = 0;
			for (int d2 = 0; d2 < dim; d2++)
				temp_quad_vector[d1] += C_G[d1][d2] * q[d2];
		}
		for (int d = 0; d < dim; d++)
			quadratic_form += q[d] * temp_quad_vector[d];

		gamma_sq_sum_quartic = stat.gamma*stat.gamma*(this->idList.size()*stat.qSquareNorm*stat.qSquareNorm
			- 4 * stat.qSquareNorm*ip_aG - 4 * ip_vG + 2 * stat.qSquareNorm*S_G + h_G + 4 * quadratic_form);

		//return 0;
		return (a*gamma_sq_sum_quartic + b * gamma_sum + c * idList.size());
	}

	if (stat.kernel_type == 1) //Triangular kernel
	{
		for (int d = 0; d < dim; d++)
			ip_aG += q[d] * a_G[d];
		gamma_sum = stat.gamma*stat.gamma*(sum_alpha*stat.qSquareNorm - 2 * ip_aG + S_G);
		a = -sqrt(idList.size() / (4 * gamma_sum));
		c = 1 + 1 / (4 * a);

		return max(a*gamma_sum + c * idList.size(), 0.0);
	}

	if (stat.kernel_type == 2) //Cosine kernel
	{
		ub = u_MBR(q, boundary, dim);
		//x_max = stat.gamma*ub;
		x_max = pi * ub / (2 * stat.gamma);

		for (int d = 0; d < dim; d++)
			ip_aG += q[d] * a_G[d];
		//gamma_sum = stat.gamma*stat.gamma*(sum_alpha*stat.qSquareNorm - 2 * ip_aG + S_G);
		gamma_sum = ((pi*pi) / (4 * stat.gamma*stat.gamma))*(sum_alpha*stat.qSquareNorm - 2 * ip_aG + S_G);

		if (x_max > pi / 2.0)
			x_max = pi / 2.0;

		a = -sin(x_max) / (2 * x_max);
		c = cos(x_max) + x_max * sin(x_max) / 2.0;

		return max(a*gamma_sum + c * idList.size(), 0.0);
	}

	if (stat.kernel_type == 3) //Exponential kernel
	{
		for (int d = 0; d < dim; d++)
			ip_aG += q[d] * a_G[d];
		gamma_sum = stat.gamma*stat.gamma*(sum_alpha*stat.qSquareNorm - 2 * ip_aG + S_G);
		t_star = sqrt(gamma_sum / sum_alpha);

		a = -exp(-t_star) / (2 * t_star);
		c = exp(-t_star)*(t_star + 2) / 2.0;

		return max(a*gamma_sum + c * idList.size(), 0.0);
	}

	return inf;
}

double kdQuadAugNode::UB(double*q, int dim, statistics& stat)
{
	double lb, ub;
	double l2, u2;
	double exp_l2, exp_u2;
	double m_u, k_u;
	double a, b, c; //coefficients of quadratic function
	double x_min, x_max;
	double y_min, y_max;

	lb = ell_MBR(q, boundary, dim);
	ub = u_MBR(q, boundary, dim);

	//use MBR
	if (stat.kernel_type == 0) //Gaussian kernel
	{
		l2 = lb * lb;
		u2 = ub * ub;

		//l2=u2, we cannot use mx+c to act as upper bound computationally
		if (u2 - l2 < stat.epsilon)
			return sum_alpha * exp(-stat.gamma*l2);

		exp_l2 = exp(-stat.gamma*l2);
		exp_u2 = exp(-stat.gamma*u2);

		//compute m and k
		m_u = (exp_u2 - exp_l2) / (stat.gamma*(u2 - l2));
		k_u = (u2*exp_l2 - l2 * exp_u2) / (u2 - l2);

		a = -(m_u + exp_u2) / (stat.gamma*(u2 - l2));
		b = m_u - a * (stat.gamma*(l2 + u2));
		c = k_u + a * stat.gamma*stat.gamma*l2*u2;

		return (a*gamma_sq_sum_quartic + b * gamma_sum + c * idList.size());
	}

	if (stat.kernel_type == 1) //Triangular kernel
	{
		x_min = stat.gamma*lb;
		x_max = stat.gamma*ub;

		if (x_max - x_min < small_epsilon)
			return sum_alpha * max(1 - x_min, 0.0);

		y_min = max(1 - x_min, 0.0);
		y_max = max(1 - x_max, 0.0);

		a = (y_max - y_min) / (x_max*x_max - x_min * x_min);
		c = (x_max*x_max*y_min - x_min * x_min*y_max) / (x_max*x_max - x_min * x_min);

		return (a*gamma_sum + c * idList.size());
	}

	if (stat.kernel_type == 2) //Cosine kernel
	{
		x_min = pi * lb / (2 * stat.gamma);
		x_max = pi * ub / (2 * stat.gamma);
		
		if (x_min >= pi / 2)
			return 0.0;
		else
			y_min = cos(x_min);

		if (x_max >= pi / 2)
			y_max = 0;
		else
			y_max = cos(x_max);

		if (x_max - x_min < small_epsilon)
			return sum_alpha * y_max;

		a = (y_max - y_min) / (x_max*x_max - x_min * x_min);
		c = (x_max*x_max*y_min - x_min * x_min*y_max) / (x_max*x_max - x_min * x_min);

		return (a*gamma_sum + c * idList.size());
	}

	if (stat.kernel_type == 3) //Exponential kernel
	{
		x_min = stat.gamma*lb;
		x_max = stat.gamma*ub;

		if (x_max - x_min < small_epsilon)
			return sum_alpha * exp(-x_min);

		y_min = exp(-x_min);
		y_max = exp(-x_max);

		a = (y_max - y_min) / (x_max*x_max - x_min * x_min);
		c = (x_max*x_max*y_min - x_min * x_min*y_max) / (x_max*x_max - x_min * x_min);

		return (a*gamma_sum + c * idList.size());
	}

	return -inf;
}

void kdQuadAugNode::update_Aug(Node*node, Tree*t)
{
	this->update_linearAugInfo((kdQuadAugNode*)node, t);
	this->update_QuadAugInfo((kdQuadAugNode*)node, t);
}

void kdQuadAugNode::update_QuadAugInfo(kdQuadAugNode*node, Tree*t)
{
	int id;
	double quad;
	double quar;

	node->C_G = new double*[t->dim];
	for (int d = 0; d < t->dim; d++)
		node->C_G[d] = new double[t->dim];

	node->v_G = new double[t->dim];
	node->temp_quad_vector = new double[t->dim];
	
	node->h_G = 0;
	for (int d = 0; d < t->dim; d++)
		node->v_G[d] = 0;

	for (int d_1 = 0; d_1 < t->dim; d_1++)
		for (int d_2 = 0; d_2 < t->dim; d_2++)
			node->C_G[d_1][d_2] = 0;

	for (int i = 0; i < (int)node->idList.size(); i++)
	{
		id = node->idList[i];
		quad = 0;
		quar = 0;
		
		for (int d = 0; d < t->dim; d++)
			quad += t->dataMatrix[id][d]*t->dataMatrix[id][d];
		quar = quad * quad;

		node->h_G += quar;

		for (int d = 0; d < t->dim; d++)
			node->v_G[d] += quad * t->dataMatrix[id][d];

		for (int d_1 = 0; d_1 < t->dim; d_1++)
			for (int d_2 = 0; d_2 < t->dim; d_2++)
				node->C_G[d_1][d_2] += t->dataMatrix[id][d_1] * t->dataMatrix[id][d_2];
	}

	if ((int)node->idList.size() <= t->leafCapacity) //this is the leaf node
		return;

	update_QuadAugInfo((kdQuadAugNode*)node->childVector[0], t);
	update_QuadAugInfo((kdQuadAugNode*)node->childVector[1], t);
}

kdQuadAugNode*kdQuadAugNode::createNode()
{
	return new kdQuadAugNode();
}

//kd-tree
kdTree::kdTree(int dim,double**dataMatrix,double*alphaArray,int leafCapacity)
{
	this->dim = dim;
	this->dataMatrix = dataMatrix;
	this->leafCapacity = leafCapacity;
	this->alphaArray = alphaArray;
}

void kdTree::getNode_Boundary(kdNode*node)
{
	//double sum_alpha;
	int id;
	node->boundary=new double*[dim];
	for(int d=0;d<dim;d++)
		node->boundary[d]=new double[2];

	for(int d=0;d<dim;d++)
	{
		node->boundary[d][0]=inf;
		node->boundary[d][1]=-inf;
	}

	for(int d=0;d<dim;d++)
	{
		for(int i=0;i<(int)node->idList.size();i++)
		{
			id=node->idList[i];
			if(dataMatrix[id][d]<node->boundary[d][0])
				node->boundary[d][0]=dataMatrix[id][d];

			if(dataMatrix[id][d]>node->boundary[d][1])
				node->boundary[d][1]=dataMatrix[id][d];
		}
	}
}

double kdTree::obtain_SplitValue(kdNode*node,int split_Dim)
{
	vector<double> tempVector;
	int id;
	int middle_left,middle_right,middle;
	for(int i=0;i<(int)node->idList.size();i++)
	{
		id=node->idList[i];
		tempVector.push_back(dataMatrix[id][split_Dim]);
	}

	sort(tempVector.begin(),tempVector.end());

	if((int)tempVector.size()%2==0)//even number
	{
		middle_right=(int)tempVector.size()/2;
		middle_left=middle_right-1;

		return ((tempVector[middle_left]+tempVector[middle_right])/2.0);
	}
	else
	{
		middle=((int)tempVector.size()-1)/2;
		return tempVector[middle];
	}

	tempVector.clear();
}

void kdTree::KD_Tree_Recur(kdNode*node,int split_Dim)
{
	int id;
	int counter;
	//base case
	if((int)node->idList.size()<=leafCapacity)
	{
		/*node->initModel_inMemory(dataMatrix,alphaArray,dim,stat);
		node->createModel_inMemory(dataMatrix,alphaArray,dim,stat);*/
		return;
	}
	
	//added for testing
	//split_Dim=select_split_Dim(node);
	double splitValue=obtain_SplitValue(node,split_Dim); //code here

	//create two children
	kdNode*leftNode;
	kdNode*rightNode;

	leftNode=node->createNode();
	rightNode=node->createNode();

	counter=0;
	int halfSize=((int)node->idList.size())/2;
	for(int i=0;i<(int)node->idList.size();i++)
	{
		id=node->idList[i];
		if(dataMatrix[id][split_Dim]<=splitValue && counter<=halfSize)
		{
			leftNode->idList.push_back(id);
			counter++;
		}
		else
			rightNode->idList.push_back(id);
	}

	getNode_Boundary(leftNode);
	getNode_Boundary(rightNode);

	KD_Tree_Recur(leftNode,(split_Dim+1)%dim);
	KD_Tree_Recur(rightNode,(split_Dim+1)%dim);

	node->childVector.push_back(leftNode);
	node->childVector.push_back(rightNode);
}

int kdTree::select_split_Dim(kdNode*node)
{
	double interval_difference=0;
	double largest_difference=0;
	int best_Dim=-1;

	for(int d=0;d<dim;d++)
	{
		interval_difference=(node->boundary[d][1]-node->boundary[d][0]);
		if(largest_difference<interval_difference)
		{
			largest_difference=interval_difference;
			best_Dim=d;
		}
	}

	return best_Dim;
}

void kdTree::build_kdTree(statistics& stat)
{
	for(int i=0;i<stat.n;i++)
		rootNode->idList.push_back(i);

	getNode_Boundary((kdNode*)rootNode);
	KD_Tree_Recur((kdNode*)rootNode,0);
	initTree_alpha((kdNode*)rootNode);
}

void kdTree::initTree_alpha(kdNode*node)
{
	double sum_alpha=0;
	int id;
	for(int i=0;i<(int)node->idList.size();i++)
	{
		id=node->idList[i];
		sum_alpha+=alphaArray[id];
	}
	node->sum_alpha=sum_alpha;

	if((int)node->idList.size()>leafCapacity)
	{
		initTree_alpha((kdNode*)node->childVector[0]);
		initTree_alpha((kdNode*)node->childVector[1]);
	}
}
void kdTree::updateAugment(kdNode*node)
{
	node->update_Aug(node,this);
}

void kdTree::lookUp_KDTree()
{
	lookUp_KDTree_Recur((kdNode*)rootNode);
}

void kdTree::lookUp_KDTree_Recur(kdNode*node)
{
	int idListSize=node->idList.size();
	for(int i=0;i<idListSize;i++)
		cout<<node->idList[i]<<" ";
	cout<<endl;
	cout<<"sum_alpha: "<<node->sum_alpha<<endl;

	if(idListSize>leafCapacity)
	{
		lookUp_KDTree_Recur((kdNode*)node->childVector[0]);
		lookUp_KDTree_Recur((kdNode*)node->childVector[1]);
	}
	else
	{
		int id;
		for(int i=0;i<idListSize;i++)
		{
			id=node->idList[i];
			cout<<"(";
			for(int d=0;d<dim-1;d++)
				cout<<dataMatrix[id][d]<<",";
			cout<<dataMatrix[id][dim-1]<<")"<<endl;
		}
	}
}

//kd-tree_adv
void kdTree_adv::KD_Tree_adv_Recur(kdNode*node,int split_Dim)
{
	int id;
	int counter;
	//base case
	if((int)node->idList.size()<=leafCapacity)
	{
		getNode_Boundary(node);
		//node->initModel_inMemory(dataMatrix,alphaArray,dim,stat);
		//node->createModel_inMemory(dataMatrix,alphaArray,dim,stat);

		return;
	}
	
	//added for testing
	double splitValue=obtain_SplitValue(node,split_Dim); //code here

	//create two children
	kdNode*leftNode;
	kdNode*rightNode;

	leftNode=node->createNode();
	rightNode=node->createNode();

	counter=0;
	int halfSize=((int)node->idList.size())/2;
	for(int i=0;i<(int)node->idList.size();i++)
	{
		id=node->idList[i];
		if(dataMatrix[id][split_Dim]<=splitValue && counter<=halfSize)
		{
			leftNode->idList.push_back(id);
			counter++;
		}
		else
			rightNode->idList.push_back(id);
	}

	KD_Tree_adv_Recur(leftNode,(split_Dim+1)%dim);
	KD_Tree_adv_Recur(rightNode,(split_Dim+1)%dim);

	//get back the boundary of leftNode and rightNode using O(d) time by merging boundaries from left and right node
	merge_Boundary(node,leftNode->boundary,rightNode->boundary);

	node->childVector.push_back(leftNode);
	node->childVector.push_back(rightNode);
}

void kdTree_adv::merge_Boundary(kdNode*node,double**boundary_1,double**boundary_2)
{
	node->boundary=new double*[dim];
	for(int d=0;d<dim;d++)
		node->boundary[d]=new double[2];

	//merge two boundaries
	for(int d=0;d<dim;d++)
	{
		if(boundary_1[d][0]<boundary_2[d][0])
			node->boundary[d][0]=boundary_1[d][0];
		else
			node->boundary[d][0]=boundary_2[d][0];

		if(boundary_1[d][1]<boundary_2[d][1])
			node->boundary[d][1]=boundary_2[d][1];
		else
			node->boundary[d][1]=boundary_1[d][1];
	}
}

void kdTree_adv::build_kdTree_adv(statistics& stat)
{
	for(int i=0;i<stat.n;i++)
		rootNode->idList.push_back(i);

	KD_Tree_adv_Recur((kdNode*)rootNode,0);
	initTree_alpha((kdNode*)rootNode);
}