#pragma once
#ifndef PROGRESSIVE_H
#define PROGRESSIVE_H

#include "Grid.h"
#include "alg_visual.h"

void findCenter(Grid& grid);
void Divide(queue<Grid>& grid_Queue);
void progressive_Evaluation(queue<Grid>& grid_Queue, Tree& tree, statistics& stat);
void progressive_outResult(queue<Grid>& grid_Queue, statistics& stat);

#endif