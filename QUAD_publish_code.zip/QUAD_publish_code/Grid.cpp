#include "Grid.h"

void sequential_Grid_Preprocess(spatial_pos**& queryMatrix, statistics& stat, vector<Grid>& GridVector)
{
	int row_b_size;
	int col_b_size;

	Grid tempGrid;

	row_b_size = (int)floor((double)stat.n_row / stat.row_blocks);
	col_b_size = (int)floor((double)stat.n_col / stat.col_blocks);

	for (int r = 0; r < stat.row_blocks; r++)
	{
		for (int c = 0; c < stat.col_blocks; c++)
		{
			tempGrid.row_id_left = r * row_b_size;
			tempGrid.col_id_left = c * col_b_size;

			if (r != stat.row_blocks - 1)
				tempGrid.row_id_right = (r + 1)*row_b_size - 1;
			else
				tempGrid.row_id_right = stat.n_row - 1;

			if (c != stat.col_blocks - 1)
				tempGrid.col_id_right = (c + 1)*col_b_size - 1;
			else
				tempGrid.col_id_right = stat.n_col - 1;

			tempGrid.Q_boundary = new double*[2];
			for (int d = 0; d < 2; d++)
				tempGrid.Q_boundary[d] = new double[2];

			tempGrid.Q_boundary[0][0] = queryMatrix[tempGrid.row_id_left][tempGrid.col_id_left].i_coord;
			tempGrid.Q_boundary[0][1] = queryMatrix[tempGrid.row_id_right][tempGrid.col_id_left].i_coord;

			tempGrid.Q_boundary[1][0] = queryMatrix[tempGrid.row_id_left][tempGrid.col_id_left].j_coord;
			tempGrid.Q_boundary[1][1] = queryMatrix[tempGrid.row_id_left][tempGrid.col_id_right].j_coord;

			GridVector.push_back(tempGrid);
		}
	}
}

void sequential_Grid_Preprocess_Lipschitz(spatial_pos**& queryMatrix, statistics& stat, vector<Grid>& GridVector)
{
	int row_b_size;
	int col_b_size;
	int center_x,center_y;
	double length_x, length_y;

	Grid tempGrid;

	row_b_size = (int)floor((double)stat.n_row / stat.row_blocks);
	col_b_size = (int)floor((double)stat.n_col / stat.col_blocks);

	for (int r = 0; r < stat.row_blocks; r++)
	{
		for (int c = 0; c < stat.col_blocks; c++)
		{
			tempGrid.row_id_left = r * row_b_size;
			tempGrid.col_id_left = c * col_b_size;

			if (r != stat.row_blocks - 1)
				tempGrid.row_id_right = (r + 1)*row_b_size - 1;
			else
				tempGrid.row_id_right = stat.n_row - 1;

			if (c != stat.col_blocks - 1)
				tempGrid.col_id_right = (c + 1)*col_b_size - 1;
			else
				tempGrid.col_id_right = stat.n_col - 1;

			center_x = (int)floor((tempGrid.row_id_left + tempGrid.row_id_right) / 2.0);
			center_y = (int)floor((tempGrid.col_id_left + tempGrid.col_id_right) / 2.0);

			tempGrid.center = new double[stat.dim];
			tempGrid.center[0] = queryMatrix[center_x][center_y].i_coord;
			tempGrid.center[1] = queryMatrix[center_x][center_y].j_coord;

			length_x = tempGrid.center[0] - queryMatrix[tempGrid.row_id_right][tempGrid.col_id_right].i_coord;
			length_y = tempGrid.center[1] - queryMatrix[tempGrid.row_id_right][tempGrid.col_id_right].j_coord;
			tempGrid.max_length = sqrt(length_x * length_x + length_y * length_y);

			GridVector.push_back(tempGrid);
		}
	}
}

void Grid_refine(Node*curNode, statistics& stat, Tree& tree, double& f_cur_L, double& f_cur_U)
{
	double sq_Euclid_LB;
	double sq_Euclid_UB;
	double ell;
	double u;
	f_cur_L = 0;
	f_cur_U = 0;

	for (int i = 0; i < (int)curNode->idList.size(); i++)
	{
		ell=ell_MBR(tree.dataMatrix[curNode->idList[i]], stat.grid_ptr->Q_boundary, stat.dim);
		u = u_MBR(tree.dataMatrix[curNode->idList[i]], stat.grid_ptr->Q_boundary, stat.dim);

		sq_Euclid_LB = ell * ell;
		sq_Euclid_UB = u * u;

		f_cur_L += exp(-stat.gamma*sq_Euclid_UB);
		f_cur_U += exp(-stat.gamma*sq_Euclid_LB);
	}
}