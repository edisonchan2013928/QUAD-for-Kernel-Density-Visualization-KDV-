#include "SS_visual.h"

double SCAN(double*q,double**featureVector, statistics& stat)
{
	double incr_value;
	double sq_euclid_value;
	double euclid_value;

	incr_value = 0;

	for (int i = 0; i < stat.n; i++)
	{
		sq_euclid_value = sq_euclid_dist(q, featureVector[i], stat.dim);
		if (stat.kernel_type == 0) //Gaussian kernel			
			incr_value += exp(-stat.gamma*sq_euclid_value);
		if (stat.kernel_type == 1) //Triangular kernel
		{
			euclid_value = sqrt(sq_euclid_value);
			incr_value += max(1 - stat.gamma*euclid_value, 0.0);
		}
		if (stat.kernel_type == 2) //Cosine kernel
		{
			if (sq_euclid_value <= stat.gamma*stat.gamma)
			{
				euclid_value = sqrt(sq_euclid_value);
				incr_value += cos(pi * euclid_value / (2 * stat.gamma));
			}
		}
		if (stat.kernel_type == 3) //Exponential kernel
		{
			euclid_value = sqrt(sq_euclid_value);
			incr_value += exp(-stat.gamma*euclid_value);
		}
	}

	//incr_value = incr_value * stat.alpha;

	return incr_value;
}

int checkThreshold(double out_value,vector<double> tau_List)
{
	if (out_value <= tau_List[0])
		return 0;

	for (int t = 1; t < (int)tau_List.size()-1; t++)
	{
		if (out_value > tau_List[t] && out_value <= tau_List[t + 1])
			return t;
	}

	return (tau_List.size() - 1);
}

void KDE_visual(double**queryVector, double**featureVector, statistics& stat)
{
	int q = 0;
	for (int i = 0; i < stat.n_row; i++)
	{
		for (int j = 0; j < stat.n_col; j++)
		{
			stat.out_matrix[i][j] = SCAN(queryVector[q], featureVector, stat);

			if (stat.q_type == 1)//tau-KAQ
			{
				//multi-class classification
				//stat.out_matrix[i][j] = checkThreshold(stat.out_matrix[i][j], stat.tau_List);

				//binary classification
				if (stat.out_matrix[i][j] >= stat.tau_binary)
					stat.out_matrix[i][j] = 1;
				else
					stat.out_matrix[i][j] = -1;
			}
			q++;
		}
	}
}

double refinement(Node*curNode, statistics& stat, Tree& tree)
{
	double f_cur;
	double sq_Euclid;
	double euclid_value;
	f_cur = 0;

	for (int i = 0; i < (int)curNode->idList.size(); i++)
	{
		sq_Euclid = 0;
		for (int d = 0; d < stat.dim; d++)
			sq_Euclid += (stat.q[d] - tree.dataMatrix[curNode->idList[i]][d])*(stat.q[d] - tree.dataMatrix[curNode->idList[i]][d]);

		if (stat.kernel_type == 0)
			f_cur += exp(-sq_Euclid);
		if (stat.kernel_type == 1)
		{
			euclid_value = sqrt(sq_Euclid);
			f_cur += max(1 - stat.gamma*euclid_value, 0.0);
		}
		if (stat.kernel_type == 2)
		{
			if (sq_Euclid <= stat.gamma*stat.gamma)
			{
				euclid_value = sqrt(sq_Euclid);
				f_cur += cos(pi * euclid_value / (2 * stat.gamma));
			}
		}
		if (stat.kernel_type == 3) //Exponential kernel
		{
			euclid_value = sqrt(sq_Euclid);
			f_cur += exp(-stat.gamma*euclid_value);
		}
	}

	return f_cur;
}