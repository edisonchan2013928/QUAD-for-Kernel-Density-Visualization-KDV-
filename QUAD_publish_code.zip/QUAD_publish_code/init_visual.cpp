#include "init_visual.h"

void initArray(double**& featureArray, int n, int dim)
{
	featureArray = new double*[n];
	for (int i = 0; i < n; i++)
		featureArray[i] = new double[dim];

	//initalization of featureArray
	for (int i = 0; i < n; i++)
		for (int d = 0; d < dim; d++)
			featureArray[i][d] = 0;
}

void initStat(int argc, char**argv, statistics& stat)
{
	//debug
	/*char*dataFileName = (char*)"./testing/Atlanta_2d.dat";
	stat.outMatrixFileName = (char*)"./test_Result/Atlanta_2d_result_exp_M9";
	stat.q_type = 0;
	stat.method = 9;
	stat.n_row = 240;
	stat.n_col = 320;
	double b = 1.0;
	stat.epsilon = 0.05;
	stat.leafCapacity = 40;
	stat.kernel_type = 3;
	stat.gamma = 1;*/

	char*dataFileName = (char*)argv[1];
	stat.outMatrixFileName = (char*)argv[2];
	stat.q_type = atoi(argv[3]);
	stat.method = atoi(argv[4]);
	stat.n_row = atoi(argv[5]);
	stat.n_col = atoi(argv[6]);
	double b = atof(argv[7]);

	if (stat.q_type == 0) //epsilon-KVQ
		stat.epsilon = atof(argv[8]);

	if (stat.q_type == 1) //tau-KVQ
		stat.tau_binary = atof(argv[8]); //only for binary-classification setting

	stat.leafCapacity = atoi(argv[9]); //used in tKDC, KARL and QUAD
	stat.kernel_type = atoi(argv[10]);
	stat.gamma = 1;

	//update the time limit in stat for progressive visualization (anytime setting)
	if (stat.method >= 16 && stat.method <= 19)
		stat.time_limit = atof(argv[11]);

	extract_FeatureVector(dataFileName, stat);
	updateRegion(stat);

	preprocessData(stat, b);
	obtain_alpha(stat);

	if (stat.n_row != 1 || stat.n_col != 1)
	{
		stat.incr_row = (stat.row_U - stat.row_L) / (stat.n_row - 1);
		stat.incr_col = (stat.col_U - stat.col_L) / (stat.n_col - 1);
	}	

	if (stat.n_row == 1)
		stat.incr_row = 0;
	if (stat.n_col == 1)
		stat.incr_col = 0;

	stat.out_matrix = new double*[stat.n_row];
	for (int i = 0; i < stat.n_row; i++)
		stat.out_matrix[i] = new double[stat.n_col];

	stat.out_vector = new double[stat.n_row*stat.n_col];

	//Used for progressive visualization
	for (int i = 0; i < stat.n_row; i++)
		for (int j = 0; j < stat.n_col; j++)
			stat.out_matrix[i][j] = -100;
}

void loadRegion(char*regionFileName, double& row_L, double& row_U, double& col_L, double& col_U)
{
	fstream regionFile;

	regionFile.open(regionFileName);

	if (regionFile.is_open() == false)
	{
		cout << "Cannot open region file!" << endl;
		exit(0);
	}

	regionFile >> row_L;
	regionFile >> row_U;
	regionFile >> col_L;
	regionFile >> col_U;

	regionFile.close();
}

void updateRegion(statistics& stat)
{
	stat.row_L = inf;
	stat.row_U = -inf;
	stat.col_L = inf;
	stat.col_U = -inf;

	for (int i = 0; i < stat.n; i++)
	{
		if (stat.featureVector[i][0] < stat.row_L)
			stat.row_L = stat.featureVector[i][0];
		if (stat.featureVector[i][0] > stat.row_U)
			stat.row_U = stat.featureVector[i][0];

		if (stat.featureVector[i][1] < stat.col_L)
			stat.col_L = stat.featureVector[i][1];
		if (stat.featureVector[i][1] > stat.col_U)
			stat.col_U = stat.featureVector[i][1];
	}
}

void init_tauList(char*tau_List_FileName, vector<double>& tau_List)
{
	fstream tau_List_File;
	int tau_number;
	double tau_value;

	tau_List_File.open(tau_List_FileName);

	if (tau_List_File.is_open() == false)
	{
		cout << "Cannot open tau_List File!" << endl;
		exit(0);
	}

	tau_List_File >> tau_number;

	for (int t = 0; t < tau_number; t++)
	{
		tau_List_File >> tau_value;
		tau_List.push_back(tau_value);
	}
}

//void obtain_bandwidth(double**featureArray,int n, double& h0, double& h1,double b)
void preprocessData(statistics& stat, double b)
{
	double sigma_0, sigma_1;
	double sum_X0, sum_X1;
	double mean_X0, mean_X1;
	double sum_square_X0, sum_square_X1;
	double sqrt_h0;
	double sqrt_h1;

	sum_X0 = 0; sum_X1 = 0;
	sum_square_X0 = 0, sum_square_X1 = 0;

	for (int i = 0; i < stat.n; i++)
	{
		sum_X0 += stat.featureVector[i][0];
		sum_X1 += stat.featureVector[i][1];

		sum_square_X0 += stat.featureVector[i][0] * stat.featureVector[i][0];
		sum_square_X1 += stat.featureVector[i][1] * stat.featureVector[i][1];
	}

	mean_X0 = sum_X0 / (double)stat.n;
	mean_X1 = sum_X1 / (double)stat.n;

	sigma_0 = sqrt((sum_square_X0 - stat.n * mean_X0*mean_X0) / ((double)stat.n));
	sigma_1 = sqrt((sum_square_X1 - stat.n * mean_X1*mean_X1) / ((double)stat.n));

	stat.h0 = b * pow((double)stat.n, -1 / 6.0)*sigma_0;
	stat.h1 = b * pow((double)stat.n, -1 / 6.0)*sigma_1;

	if (stat.kernel_type == 0) //Gaussian kernel
	{
		sqrt_h0 = sqrt(2 * stat.h0);
		sqrt_h1 = sqrt(2 * stat.h1);
	}
	else //Other kernels
	{
		sqrt_h0 = sqrt(stat.h0);
		sqrt_h1 = sqrt(stat.h1);
	}
	
	for (int i = 0; i < stat.n; i++)
	{
		stat.featureVector[i][0] /= sqrt_h0;
		stat.featureVector[i][1] /= sqrt_h1;
	}
}

void obtain_alpha(statistics& stat)
{
	if (stat.kernel_type == 0) //Gaussian kernel function
		stat.alpha = 1 / (2 * pi*sqrt(stat.h0*stat.h1)*stat.n);
	else //Other kernel functions
		stat.alpha = 1 / (sqrt(stat.h0*stat.h1)*stat.n);
}

void extract_FeatureVector(char*fileName, statistics& stat)
{
	//load data to feature array
	fstream file;
	int n;
	int dim;

	file.open(fileName);
	if (file.is_open() == false)
	{
		cout << "Cannot Open File!" << endl;
		exit(1);
	}

	file >> n;
	file >> dim;

	stat.n = n;
	if (stat.dim != dim)
	{
		cout << "dimension is not matched!" << endl;
		exit(0);
	}

	stat.featureVector = new double*[n];
	for (int i = 0; i < n; i++)
		stat.featureVector[i] = new double[dim];

	for (int i = 0; i < n; i++)
		for (int d = 0; d < dim; d++)
			file >> stat.featureVector[i][d];

	file.close();
}

void saveMatrix_toFile(statistics& stat)
{
	fstream file;
	file.open(stat.outMatrixFileName, ios::in | ios::out | ios::trunc);
	if (file.is_open() == false)
	{
		cout << "Cannot Open File!" << endl;
		return;
	}

	for (int i = 0; i < stat.n_row; i++)
	{
		for (int j = 0; j < stat.n_col; j++)
			file << stat.out_matrix[i][j] << " ";
		file << endl;
	}

	file.close();
}

#ifdef STATISTICS
void loadMatrix_fromFile(char*fileName, statistics& stat)
{
	fstream file;
	file.open(fileName);
	if (file.is_open() == false)
	{
		cout << "Cannot Open File!" << endl;
		return;
	}

	//init out_Matrix in statistics
	stat.out_matrix = new double*[stat.n_row];
	for (int i = 0; i < stat.n_row; i++)
		stat.out_matrix[i] = new double[stat.n_col];
	
	for (int i = 0; i < stat.n_row; i++)
	{
		for (int j = 0; j < stat.n_col; j++)
			file >> stat.out_matrix[i][j];
	}

	file.close();
}

void find_largestKDE_pos(statistics& stat)
{
	double max_KDE = 0;
	for (int i = 0; i < stat.n_row; i++)
	{
		for (int j = 0; j < stat.n_col; j++)
		{
			if (stat.out_matrix[i][j] > max_KDE)
			{
				max_KDE = stat.out_matrix[i][j];
				stat.select_x_pos = i;
				stat.select_y_pos = j;
			}
		}
	}
}

#endif

void vectorized_preprocess(double**& queryVector, statistics& stat)
{
	double i_coord;
	double j_coord;

	double sqrt_h0;
	double sqrt_h1;

	//(1) obtain back all regions
	queryVector = new double*[stat.n_row*stat.n_col];
	for (int q = 0; q < stat.n_row*stat.n_col; q++)
		queryVector[q] = new double[2];

	sqrt_h0 = sqrt(2 * stat.h0);
	sqrt_h1 = sqrt(2 * stat.h1);
	for (int i = 0; i < stat.n_row; i++)
	{
		i_coord = (stat.row_L + i * stat.incr_row) / sqrt_h0;
		for (int j = 0; j < stat.n_col; j++)
		{
			j_coord = (stat.col_L + j * stat.incr_col) / sqrt_h1;
			queryVector[i*stat.n_col + j][0] = i_coord; //transform query in 1st coord
			queryVector[i*stat.n_col + j][1] = j_coord; //transform query in 2nd coord
		}
	}
}

void queries_preprocess(double**& queryVector, spatial_pos**& queryMatrix, statistics& stat,int method_Qset)
{
	double i_coord;
	double j_coord;

	double sqrt_h0;
	double sqrt_h1;

	//(1) obtain back all regions
	queryVector = new double*[stat.n_row*stat.n_col];
	for (int q = 0; q < stat.n_row*stat.n_col; q++)
		queryVector[q] = new double[2];

	if (method_Qset == 2)
	{
		queryMatrix = new spatial_pos*[stat.n_row];
		for (int i = 0; i < stat.n_row; i++)
			queryMatrix[i] = new spatial_pos[stat.n_col];
	}

	if (stat.kernel_type == 0) //Gaussian kernel
	{
		sqrt_h0 = sqrt(2 * stat.h0);
		sqrt_h1 = sqrt(2 * stat.h1);
	}
	else //Other kernels
	{
		sqrt_h0 = sqrt(stat.h0);
		sqrt_h1 = sqrt(stat.h1);
	}

	for (int i = 0; i < stat.n_row; i++)
	{
		i_coord = (stat.row_L + i * stat.incr_row) / sqrt_h0;
		for (int j = 0; j < stat.n_col; j++)
		{
			j_coord = (stat.col_L + j * stat.incr_col) / sqrt_h1;

			if (method_Qset == 1) //vectorized_preprocess
			{
				queryVector[i*stat.n_col + j][0] = i_coord; //transform query in 1st coord
				queryVector[i*stat.n_col + j][1] = j_coord; //transform query in 2nd coord
			}
			if (method_Qset == 2) //consider its spatial relationship
			{
				queryVector[i*stat.n_col + j][0] = i_coord; //transform query in 1st coord
				queryVector[i*stat.n_col + j][1] = j_coord; //transform query in 2nd coord
				queryMatrix[i][j].i_coord = i_coord;
				queryMatrix[i][j].j_coord = j_coord;
			}
		}
	}
}

void outVec_2_outMatrix(statistics& stat)
{
	for (int r = 0; r < stat.n_row; r++)
		for (int c = 0; c < stat.n_col; c++)
			stat.out_matrix[r][c] = stat.out_vector[r*stat.n_col + c];
}

void init_outVec(statistics& stat)
{
	for (int q = 0; q < stat.n_row*stat.n_col; q++)
		stat.out_vector[q]=-1;
}

//bug_testing
void outputArray(double**featureArray, int n, int dim)
{
	for (int i = 0; i < n; i++)
	{
		for (int d = 0; d < dim; d++)
			cout << featureArray[i][d] << " ";
		cout << endl;
	}
}
