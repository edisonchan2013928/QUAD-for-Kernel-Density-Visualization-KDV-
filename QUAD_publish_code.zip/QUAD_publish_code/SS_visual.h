#pragma once
#ifndef SS_VISUAL_H
#define SS_VISUAL_H

#include "init_visual.h"
#include "Euclid_Bound.h"
#include "Tree.h"

double SCAN(double*q, double**featureVector, statistics& stat); //basic solution for KDE
int checkThreshold(double out_value, vector<double> tau_List); //check whether the output value belongs to which classes
//void KDE_visual(double**& featureVector, statistics& stat); //handle visualization query
void KDE_visual(double**queryVector,double**featureVector, statistics& stat); //handle visualization query
double refinement(Node*curNode, statistics& stat, Tree& tree); //refinement in the leaf node

#endif