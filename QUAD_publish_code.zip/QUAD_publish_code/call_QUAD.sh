g++ -c alg_visual.cpp -w -o alg_visual.o -std=c++11
g++ -c Euclid_Bound.cpp -w -o Euclid_Bound.o -std=c++11
g++ -c Grid.cpp -w -o Grid.o -std=c++11
g++ -c init_visual.cpp -w -o init_visual.o -std=c++11
g++ -c kd_tree.cpp -w -o kd_tree.o -std=c++11
g++ -c progressive.cpp -w -o progressive.o -std=c++11
g++ -c progressive_anytime.cpp -w -o progressive_anytime.o -std=c++11
g++ -c SS_visual.cpp -w -o SS_visual.o -std=c++11
g++ -c Tree.cpp -w -o Tree.o -std=c++11
g++ -c Validation.cpp -w -o Validation.o -std=c++11

g++ main.cpp -O3 -o main alg_visual.o Euclid_Bound.o Grid.o init_visual.o kd_tree.o progressive.o progressive_anytime.o SS_visual.o Tree.o Validation.o

#Here we demonstrate how to run our program in the Atlanta (crime) dataset. This dataset can be downloaded from this webpage http://opendata.atlantapd.org/
#After you download it, please convert this dataset into our data format (please refer to the readme.txt file.) and you can save it as Atlanta_2d.dat.

#This is the example for running the epsilon-KVQ, using our method QUAD, in Atlanta dataset, with epsilon=0.01.
#q_type=0: epsilon_KVQ 
#q_type=1: tau_KVQ
q_type=0

#relative error (epsilon)
epsilon=0.01

#Method=0: SCAN 
#Method=1: aKDE (q_type=0)/ tKDC (q_type=1)
#Method=2: KARL
#Method=9: QUAD
method=9

#Name of dataset
datasetFileName="Atlanta_2d.dat"

#Output file which stores the approximate kernel density values
outMatrixFileName="Atlanta_2d_result_exp_"$method"_q"$q_type

#Number of pixels per row
n_row=1920

#Number of pixels per column
n_col=2560

#Bandwidth factor (The same variable (cf. Table 1) as the paper: 
#"E. Gan and P. Bailis. Scalable kernel density classification via threshold-based pruning. In ACM SIGMOD, pages 945–959, 2017.")
b=1

#kernel_type=0: Gaussian kernel
#kernel_type=1: Triangular kernel
#kernel_type=2: Cosine kernel
#kernel_type=3: Exponential kernel
kernel_type=0

#Leaf capacity in the indexing framework
#We choose the default value 40, which is the same as the Scikit-learn library:
#https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KernelDensity.html#sklearn.neighbors.KernelDensity
leafCapacity=40 

./main $datasetFileName $outMatrixFileName $q_type $method $n_row $n_col $b $epsilon $leafCapacity $kernel_type

#This is the example for running the tau-KVQ, using our method QUAD, in Atlanta dataset, with tau=10000.
q_type=1
tau=10000
method=9
datasetFileName="Atlanta_2d.dat"
outMatrixFileName="Atlanta_2d_result_exp_"$method"_q"$q_type
n_row=1920
n_col=2560
b=1
kernel_type=0
leafCapacity=40

./main $datasetFileName $outMatrixFileName $q_type $method $n_row $n_col $b $tau $leafCapacity $kernel_type

#This is the example for using our method QUAD with the progressive visualization framework in Atlanta dataset, with epsilon=0.01.
#These are the method numbers, which correspond to different methods:
#Method=16: aKDE/tKDC + progressive visualization framework
#Method=17: KARL + progressive visualization framework
#Method=18: QUAD + progressive visualization framework 
#Method=19: SCAN + progressive visualization framework
q_type=0
epsilon=0.01
method=18
datasetFileName="Atlanta_2d.dat"
n_row=1920
n_col=2560
b=1
kernel_type=0
leafCapacity=40
#This is the termination time (seconds) for our code
time_limit=2
outMatrixFileName="Atlanta_2d_result_exp_"$method"_q"$q_type"_t"$time_limit

./main $datasetFileName $outMatrixFileName $q_type $method $n_row $n_col $b $epsilon $leafCapacity $kernel_type $time_limit