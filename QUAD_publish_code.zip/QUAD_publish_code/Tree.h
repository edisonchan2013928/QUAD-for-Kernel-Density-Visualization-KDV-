#ifndef TREE_H
#define TREE_H

#include "init_visual.h"
#include "Euclid_Bound.h"

class Node;
class Tree;

class Node
{
public:
	double sum_alpha;
	vector<int> idList; //idxs
	vector<Node*> childVector;

	virtual double LB(double*q,int dim,statistics& stat)=0;
	virtual double UB(double*q,int dim,statistics& stat)=0;

	virtual Node*createNode()=0;
	virtual void update_Aug(Node*node,Tree*t)=0;

	//Used for Query Groups
	int Q_id;
};

class Tree
{
public:
	int dim;
	double**dataMatrix;
	double*alphaArray;
	int leafCapacity; //Set to be 20 in tKDC
	Node*rootNode;

	//Used for Query Groups
	vector<bound_pair> Q_boundList;
	vector<bool> Q_filter;

	void update_Q_id();
	void update_Q_filter(Node*node);
};

#endif