Before you read our script file (call_QUAD.sh), please make sure you understand the concepts of our paper [4] (QUAD.pdf) and the data format.
In this published code, it can support the following methods:
1: SCAN
2: aKDE [1]
3: tKDC [2]
4: KARL [3]
5: QUAD (our work) [4]
Moreover, we can also combine these methods with the progressive visualization framework (cf. Section 6 in [4]).

In our code, we adopt the following data format to represent the datasets:
n dim
data point 1
data point 2
:
:
data point n

where n and dim are the number of points and the number of dimensions (= 2) respectively.

This code can output the file, which can be further visualized by the gnuplot script.

[1] A. G. Gray and A. W. Moore. "Nonparametric density estimation: Toward computational tractability." In SDM, pages 203–211, 2003.
[2] E. Gan and P. Bailis. "Scalable kernel density classification via threshold-based pruning." In ACM SIGMOD, pages 945–959, 2017.
[3] T. N. Chan, M. L. Yiu, and L. H. U. "KARL: fast kernel aggregation queries." In ICDE, pages 542–553, 2019.
[4] T. N. Chan, R. Cheng, and M. L. Yiu "QUAD: Quadratic-Bound-based kernel density visualization" In SIGMOD (To appear)