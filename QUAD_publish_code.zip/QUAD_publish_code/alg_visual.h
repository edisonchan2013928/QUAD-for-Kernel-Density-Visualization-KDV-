#pragma once
#ifndef ALG_VISUAL_H
#define ALG_VISUAL_H

#include "SS_visual.h"
#include "init_visual.h"
#include "kd_tree.h"
#include "Validation.h"
#include "Grid.h"
#include "progressive.h"
#include "progressive_anytime.h"

struct pqNode
{
	Node*node;
	double discrepancy;
	double node_L;
	double node_U;
};

struct pqNode_dual
{
	//int Q_id;
	Node*QNode;
	Node*PNode;
	bound_pair b_pair;
	bool Q_childAccess;
};

//This is the maximum heap
struct comparePriority
{
	bool operator()(pqNode& p1, pqNode& p2)
	{
		return p1.discrepancy < p2.discrepancy;
	}
};

struct comparePriority_dual
{
	bool operator()(pqNode_dual& p1,pqNode_dual& p2)
	{
		return (p1.b_pair.ub - p1.b_pair.lb) < (p2.b_pair.ub - p2.b_pair.lb);
	}
};

typedef priority_queue<pqNode, vector<pqNode>, comparePriority> PQ;
typedef priority_queue<pqNode_dual, vector<pqNode_dual>, comparePriority_dual> PQ_dual; 

//void GBF_iter(double*q, Tree& tree, int dim, statistics& stat, int out_i, int out_j);
void GBF_iter(Tree& tree, statistics& stat);
void visual_Algorithm(statistics& stat);

#endif