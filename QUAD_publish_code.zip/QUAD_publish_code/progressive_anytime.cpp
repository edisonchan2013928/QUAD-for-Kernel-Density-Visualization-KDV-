#include "progressive_anytime.h"

void evaluate_KDE(Grid& grid, Tree& tree, statistics& stat)
{
	stat.qSquareNorm = computeSqNorm(stat.queryVector[grid.center_id[0] * stat.n_col + grid.center_id[1]], stat.dim);
	stat.q = stat.queryVector[grid.center_id[0] * stat.n_col + grid.center_id[1]];
	stat.out_i = grid.center_id[0];
	stat.out_j = grid.center_id[1];

	if (stat.method >= 16 && stat.method <= 18) //tree structure
		GBF_iter(tree, stat);
	if (stat.method == 19) //SCAN method
		stat.out_matrix[stat.out_i][stat.out_j] = SCAN(stat.q, tree.dataMatrix, stat);
	grid.KDE_Value = stat.out_matrix[stat.out_i][stat.out_j];
}

void Divide_and_Evaluate(Grid& pop_grid, queue<Grid>& grid_Queue, Tree& tree, statistics& stat)
{
	Grid grid_left_upper;
	Grid grid_right_upper;
	Grid grid_left_lower;
	Grid grid_right_lower;

	if (pop_grid.x_min_id != pop_grid.x_max_id && pop_grid.y_min_id == pop_grid.y_max_id)
	{
		grid_left_upper.x_min_id = pop_grid.x_min_id;
		grid_left_upper.x_max_id = pop_grid.center_id[0];
		grid_left_upper.y_min_id = pop_grid.y_min_id;
		grid_left_upper.y_max_id = pop_grid.y_max_id;
		grid_left_upper.parent_KDE = pop_grid.KDE_Value; //Currently we do not need this one
		grid_left_upper.KDE_Value = -100;

		grid_left_lower.x_min_id = pop_grid.center_id[0] + 1;
		grid_left_lower.x_max_id = pop_grid.x_max_id;
		grid_left_lower.y_min_id = pop_grid.y_min_id;
		grid_left_lower.y_max_id = pop_grid.y_max_id;
		grid_left_lower.parent_KDE = pop_grid.KDE_Value;
		grid_left_lower.KDE_Value = -100;

		findCenter(grid_left_upper);
		findCenter(grid_left_lower);

		evaluate_KDE(grid_left_upper, tree, stat);
		evaluate_KDE(grid_left_lower, tree, stat);

		grid_Queue.push(grid_left_upper);
		grid_Queue.push(grid_left_lower);
	}

	if (pop_grid.x_min_id == pop_grid.x_max_id && pop_grid.y_min_id != pop_grid.y_max_id)
	{
		grid_left_upper.x_min_id = pop_grid.x_min_id;
		grid_left_upper.x_max_id = pop_grid.x_max_id;
		grid_left_upper.y_min_id = pop_grid.y_min_id;
		grid_left_upper.y_max_id = pop_grid.center_id[1];
		grid_left_upper.parent_KDE = pop_grid.KDE_Value;
		grid_left_upper.KDE_Value = -100;

		grid_right_upper.x_min_id = pop_grid.x_min_id;
		grid_right_upper.x_max_id = pop_grid.x_max_id;
		grid_right_upper.y_min_id = pop_grid.center_id[1] + 1;
		grid_right_upper.y_max_id = pop_grid.y_max_id;
		grid_right_upper.parent_KDE = pop_grid.KDE_Value;
		grid_right_upper.KDE_Value = -100;

		findCenter(grid_left_upper);
		findCenter(grid_right_upper);

		evaluate_KDE(grid_left_upper, tree, stat);
		evaluate_KDE(grid_right_upper, tree, stat);

		grid_Queue.push(grid_left_upper);
		grid_Queue.push(grid_right_upper);
	}

	if (pop_grid.x_min_id != pop_grid.x_max_id && pop_grid.y_min_id != pop_grid.y_max_id)
	{
		grid_left_upper.x_min_id = pop_grid.x_min_id;
		grid_left_upper.x_max_id = pop_grid.center_id[0];
		grid_left_upper.y_min_id = pop_grid.y_min_id;
		grid_left_upper.y_max_id = pop_grid.center_id[1];
		grid_left_upper.parent_KDE = pop_grid.KDE_Value;
		grid_left_upper.KDE_Value = -100;

		grid_right_upper.x_min_id = pop_grid.x_min_id;
		grid_right_upper.x_max_id = pop_grid.center_id[0];
		grid_right_upper.y_min_id = pop_grid.center_id[1] + 1;
		grid_right_upper.y_max_id = pop_grid.y_max_id;
		grid_right_upper.parent_KDE = pop_grid.KDE_Value;
		grid_right_upper.KDE_Value = -100;

		grid_left_lower.x_min_id = pop_grid.center_id[0] + 1;
		grid_left_lower.x_max_id = pop_grid.x_max_id;
		grid_left_lower.y_min_id = pop_grid.y_min_id;
		grid_left_lower.y_max_id = pop_grid.center_id[1];
		grid_left_lower.parent_KDE = pop_grid.KDE_Value;
		grid_left_lower.KDE_Value = -100;

		grid_right_lower.x_min_id = pop_grid.center_id[0] + 1;
		grid_right_lower.x_max_id = pop_grid.x_max_id;
		grid_right_lower.y_min_id = pop_grid.center_id[1] + 1;
		grid_right_lower.y_max_id = pop_grid.y_max_id;
		grid_right_lower.parent_KDE = pop_grid.KDE_Value;
		grid_right_lower.KDE_Value = -100;

		findCenter(grid_left_upper);
		findCenter(grid_right_upper);
		findCenter(grid_left_lower);
		findCenter(grid_right_lower);

		evaluate_KDE(grid_left_upper, tree, stat);
		evaluate_KDE(grid_right_upper, tree, stat);
		evaluate_KDE(grid_left_lower, tree, stat);
		evaluate_KDE(grid_right_lower, tree, stat);

		grid_Queue.push(grid_left_upper);
		grid_Queue.push(grid_right_upper);
		grid_Queue.push(grid_left_lower);
		grid_Queue.push(grid_right_lower);
	}
}

void progressive_Evaluation_ANYTIME(queue<Grid>& grid_Queue, Tree& tree, statistics& stat)
{
	Grid grid;
	double run_time;
	double total_run_time = 0;

	grid.x_min_id = 0;
	grid.x_max_id = stat.n_row - 1;
	grid.y_min_id = 0;
	grid.y_max_id = stat.n_col - 1;
	findCenter(grid);

	//Initialization
	evaluate_KDE(grid, tree, stat);
	grid_Queue.push(grid);

	while ((int)grid_Queue.size() > 0 && total_run_time < stat.time_limit)
	{
		grid = grid_Queue.front();
		grid_Queue.pop();

		auto start_s = chrono::high_resolution_clock::now();
		Divide_and_Evaluate(grid, grid_Queue, tree, stat);
		auto end_s = chrono::high_resolution_clock::now();

		run_time = (chrono::duration_cast<chrono::nanoseconds>(end_s - start_s).count()) / 1000000000.0;

		total_run_time += run_time;
	}
}