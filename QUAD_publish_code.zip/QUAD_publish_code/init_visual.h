#pragma once

#ifndef INIT_VISUAL_H
#define INIT_VISUAL_H

#include "Library.h"
//#include "Grid.h"

const double inf = 999999999999;
const double small_epsilon = 0.000000000000001;
const double pi = 3.14159265358979323846;

//#define STATISTICS

struct Grid
{
	double**Q_boundary;
	int row_id_left;
	int row_id_right;
	int col_id_left;
	int col_id_right;

	//Used in progressive visualization
	int*center_id;
	int x_min_id;
	int x_max_id;
	int y_min_id;
	int y_max_id;

	//Used in ANYTIME
	double parent_KDE;
	double KDE_Value;

	//Used in group of queries with Lipschitz-based bounds 
	double*center;
	double max_length;
};

struct spatial_pos
{
	double i_coord;
	double j_coord;
};

struct bound_pair
{
	double lb;
	double ub;
};

struct statistics
{
	int n; //number of points in datasets
	double**out_matrix; //act as the output matrix for both T-KVQ and epsilon-KVQ
	double*out_vector; //act as the output vector for both T-KVQ and epsilon-KVQ
	double alpha; //weight alpha
	double gamma; //gamma coefficient
	int n_row; //number of discrete region in the row, e.g. 100
	int n_col; //number of discrete region in the col, e.g. 100
	double row_L,row_U; //row region, e.g. [-2,2]
	double col_L,col_U; //col region e.g. [-2,2]
	double incr_row; //incremental row e.g. (2-(-2))/100=0.04
	double incr_col; //incremental col e.g. (2-(-2))/100=0.04
	int leafCapacity; //leaf capacity for the P set
	int leafCapacity_Query; //leaf capaacity for the Q set
	double**featureVector; //feature vector of all data points
	char*outMatrixFileName; //output file Name

	double h0, h1; //bandwidth

	const int dim = 2; //dim = 2 (2d visualization)
	
	int q_type; //q_type=0: epsilon-KVQ q_type=1: tau-KVQ
	vector<double> tau_List; //thresholds used for T-KVQ
	double tau_binary; //theshold used for T-KVQ (binary setting)
	double epsilon; //epsilon value for epsilon-KVQ

	int method; //chosen method

	int kernel_type; //kernel type //0: Gaussian kernel, 1: Triangular kernel 2:Cosine kernel ...

	//Single query setting: Used in methods SCAN, tKDC and KARL (method=0,1,2) 
	double*q;
	int out_i;
	int out_j;
	int out_id;

	//Used in Dual-tree BFS
	double**Q_boundary;
	vector<int>*idList_Ptr;
	bool Q_filter;

	//Used in online stage for KARL
	double qSquareNorm;

	//Grid setting: Used in methods tKDC-Grid and KARL-Grid (method=3,4)
	double**queryVector;
	Grid*grid_ptr;

	//Used in sequential grid algorithm 
	int row_blocks; //number of blocks in row
	int col_blocks; //number of blocks in col

	//Used in progressive visualization
	int iteration;

	//Used in progressive visualization (anytime)
	double time_limit; //in terms of seconds

	#ifdef STATISTICS
	int select_x_pos;
	int select_y_pos;
	char*out_boundfileName;
	vector<double> LB_list;
	vector<double> UB_list;
	#endif
};

void initArray(double**& featureArray, int n, int dim);
void initStat(int argc, char**argv, statistics& stat);
void loadRegion(char*regionFileNamedouble, double& row_L, double& row_U, double& col_L, double& col_U);
void updateRegion(statistics& stat);
void init_tauList(char*tau_List_FileName, vector<double>& tau_List);
void preprocessData(statistics& stat, double b);
void obtain_alpha(statistics& stat);
void extract_FeatureVector(char*fileName, statistics& stat);
void saveMatrix_toFile(statistics& stat);

#ifdef STATISTICS
void loadMatrix_fromFile(char*fileName, statistics& stat);
void find_largestKDE_pos(statistics& stat);
#endif

//vectorized the 2d queryMatrix to 1d queryVector
void vectorized_preprocess(double**& queryVector, statistics& stat);
void queries_preprocess(double**& queryVector, spatial_pos**& queryMatrix, statistics& stat, int method_Qset);

void outVec_2_outMatrix(statistics& stat);

//init outVec to -1 (Used in GBF_iter_dual)
void init_outVec(statistics& stat);

//bug_testing
void outputArray(double**featureArray, int n, int dim);

#endif
