#ifndef KD_TREE_H
#define KD_TREE_H

#include "Tree.h"

class kdNode : public Node  //Gan_SIGMOD17
{
public:
	double**boundary; //boundary

	double LB(double*q,int dim,statistics& stat);
	double UB(double*q,int dim,statistics& stat);

	void update_Aug(Node*node,Tree*t){}

	kdNode*createNode();
};

class kdLinearAugNode : public kdNode //KARL
{
public:
	double*a_G;
	double S_G;

	//Used in Visualization
	double*a_G_avg;
	double b_G_avg;
	double a_G_avg_sq;

	//facilitates online (sharing) computation
	double gamma_sum;

	double LB(double*q, int dim, statistics& stat);
	double UB(double*q, int dim, statistics& stat);

	void update_linearAugInfo(kdLinearAugNode*node, Tree*t);

	void update_Aug(Node*node, Tree*t);
	kdLinearAugNode*createNode();
};

class kdQuadAugNode : public kdLinearAugNode //KARL
{
public:
	double*v_G;
	double h_G;
	double**C_G;

	//facilitates online (sharing) computation
	double gamma_sq_sum_quartic;
	double*temp_quad_vector;

	double LB(double*q, int dim, statistics& stat);
	double UB(double*q, int dim, statistics& stat);

	void update_QuadAugInfo(kdQuadAugNode*node, Tree*t);

	void update_Aug(Node*node, Tree*t);
	kdQuadAugNode*createNode();
};

class kdTree : public Tree
{
public:
	//Member functions
	kdTree(int dim,double**dataMatrix,double*alphaArray,int leafCapacity);

	void getNode_Boundary(kdNode*node);
	double obtain_SplitValue(kdNode*node,int split_Dim);
	void KD_Tree_Recur(kdNode*node,int split_Dim);
	void build_kdTree(statistics& stat);
	void initTree_alpha(kdNode*node);

	void updateAugment(kdNode*node);

	//Used for testing the correctness of the tree
	void lookUp_KDTree();
	void lookUp_KDTree_Recur(kdNode*node);

	//added this function for testing on 8/3/2018 
	int select_split_Dim(kdNode*node);
};

class kdTree_adv : public kdTree
{
public:
	//Member functions
	kdTree_adv(int dim,double**dataMatrix,double*alphaArray,int leafCapacity)
		: kdTree(dim,dataMatrix,alphaArray,leafCapacity){}
	void KD_Tree_adv_Recur(kdNode*node,int split_Dim);
	void build_kdTree_adv(statistics& stat);
	void merge_Boundary(kdNode*node,double**boundary_1,double**boundary_2);
};

#endif