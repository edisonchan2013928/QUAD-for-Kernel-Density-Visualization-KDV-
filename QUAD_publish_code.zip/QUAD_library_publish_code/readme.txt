Before you read our script file (call_QUAD.sh), please make sure you understand the concepts of our paper (QUAD.pdf) and the data format.
In our code, we adopt the following data format to represent the datasets:
n dim
data point 1
data point 2
:
:
data point n

where n and dim are the number of points and the number of dimensions (= 2) respectively.

This code can output the file, which can be further visualized by the gnuplot script.