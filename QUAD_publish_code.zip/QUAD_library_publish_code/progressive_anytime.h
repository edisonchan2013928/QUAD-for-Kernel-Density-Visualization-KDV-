#pragma once
#ifndef PROGRESSIVE_ANYTIME_H
#define PROGRESSIVE_ANYTIME_H

//#include "Grid.h"
//#include "alg_visual.h"
#include "progressive.h"

void Divide_and_Evaluate(Grid& pop_grid, queue<Grid>& grid_Queue, Tree& tree, statistics& stat);
void progressive_Evaluation_ANYTIME(queue<Grid>& grid_Queue, Tree& tree, statistics& stat);

#endif