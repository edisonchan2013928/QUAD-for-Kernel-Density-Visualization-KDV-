#include "progressive.h"

//void findCenter(Grid& grid, Grid& grid_new)
void findCenter(Grid& grid)
{
	grid.center_id = new int[2];

	/*if (grid.x_min_id == grid.x_max_id && grid.y_min_id == grid.y_max_id)
	{
		grid.center_id[0] = grid.x_min_id;
		grid.center_id[1] = grid.y_min_id;
	}*/

	if (grid.x_min_id != grid.x_max_id && grid.y_min_id == grid.y_max_id)
	{
		grid.center_id[0] = (int)floor((grid.x_min_id + grid.x_max_id) / 2.0);
		grid.center_id[1] = grid.y_min_id;
	}

	if (grid.x_min_id == grid.x_max_id && grid.y_min_id != grid.y_max_id)
	{
		grid.center_id[0] = grid.x_min_id;
		grid.center_id[1] = (int)floor((grid.y_min_id + grid.y_max_id) / 2.0);
	}
	if (grid.x_min_id != grid.x_max_id && grid.y_min_id != grid.y_max_id)
	{
		grid.center_id[0] = (int)floor((grid.x_min_id + grid.x_max_id) / 2.0);
		grid.center_id[1] = (int)floor((grid.y_min_id + grid.y_max_id) / 2.0);
	}
}

void Divide(queue<Grid>& grid_Queue)
{
	Grid grid;
	Grid grid_left_upper;
	Grid grid_right_upper;
	Grid grid_left_lower;
	Grid grid_right_lower;

	int g_size = (int)grid_Queue.size();
	for (int g = 0; g < g_size; g++)
	{
		grid = grid_Queue.front();
		grid_Queue.pop();

		if (grid.x_min_id == grid.x_max_id && grid.y_min_id == grid.y_max_id)
			continue;

		if (grid.x_min_id != grid.x_max_id && grid.y_min_id == grid.y_max_id)
		{
			grid_left_upper.x_min_id = grid.x_min_id;
			grid_left_upper.x_max_id = grid.center_id[0];
			grid_left_upper.y_min_id = grid.y_min_id;
			grid_left_upper.y_max_id = grid.y_max_id;

			grid_left_lower.x_min_id = grid.center_id[0] + 1;
			grid_left_lower.x_max_id = grid.x_max_id;
			grid_left_lower.y_min_id = grid.y_min_id;
			grid_left_lower.y_max_id = grid.y_max_id;

			findCenter(grid_left_upper);
			findCenter(grid_left_lower);

			grid_Queue.push(grid_left_upper);
			grid_Queue.push(grid_left_lower);
		}

		if (grid.x_min_id == grid.x_max_id && grid.y_min_id != grid.y_max_id)
		{
			grid_left_upper.x_min_id = grid.x_min_id;
			grid_left_upper.x_max_id = grid.x_max_id;
			grid_left_upper.y_min_id = grid.y_min_id;
			grid_left_upper.y_max_id = grid.center_id[1];

			grid_right_upper.x_min_id = grid.x_min_id;
			grid_right_upper.x_max_id = grid.x_max_id;
			grid_right_upper.y_min_id = grid.center_id[1]+1;
			grid_right_upper.y_max_id = grid.y_max_id;

			findCenter(grid_left_upper);
			findCenter(grid_right_upper);

			grid_Queue.push(grid_left_upper);
			grid_Queue.push(grid_right_upper);
		}

		if (grid.x_min_id != grid.x_max_id && grid.y_min_id != grid.y_max_id)
		{
			grid_left_upper.x_min_id = grid.x_min_id;
			grid_left_upper.x_max_id = grid.center_id[0];
			grid_left_upper.y_min_id = grid.y_min_id;
			grid_left_upper.y_max_id = grid.center_id[1];

			grid_right_upper.x_min_id = grid.x_min_id;
			grid_right_upper.x_max_id = grid.center_id[0];
			grid_right_upper.y_min_id = grid.center_id[1] + 1;
			grid_right_upper.y_max_id = grid.y_max_id;

			grid_left_lower.x_min_id = grid.center_id[0] + 1;
			grid_left_lower.x_max_id = grid.x_max_id;
			grid_left_lower.y_min_id = grid.y_min_id;
			grid_left_lower.y_max_id = grid.center_id[1];

			grid_right_lower.x_min_id = grid.center_id[0] + 1;
			grid_right_lower.x_max_id = grid.x_max_id;
			grid_right_lower.y_min_id = grid.center_id[1] + 1;
			grid_right_lower.y_max_id = grid.y_max_id;

			findCenter(grid_left_upper);
			findCenter(grid_right_upper);
			findCenter(grid_left_lower);
			findCenter(grid_right_lower);

			grid_Queue.push(grid_left_upper);
			grid_Queue.push(grid_right_upper);
			grid_Queue.push(grid_left_lower);
			grid_Queue.push(grid_right_lower);
		}
	}
}

void progressive_Evaluation(queue<Grid>& grid_Queue, Tree& tree, statistics& stat)
{
	int iter = 0;
	int g_size;
	Grid grid;

	grid.x_min_id = 0;
	grid.x_max_id = stat.n_row - 1;
	grid.y_min_id = 0;
	grid.y_max_id = stat.n_col - 1;
	findCenter(grid);
	grid_Queue.push(grid);

	//while (iter < stat.iteration || (int)grid_Queue.size() == 0)
	while (iter < stat.iteration && (int)grid_Queue.size() > 0)
	{
		g_size = (int)grid_Queue.size();
		for (int g = 0; g < g_size; g++)
		{
			grid = grid_Queue.front();
			grid_Queue.pop();

			if (stat.out_matrix[grid.center_id[0]][grid.center_id[1]] < -99)
			{
				stat.qSquareNorm = computeSqNorm(stat.queryVector[grid.center_id[0] * stat.n_col + grid.center_id[1]], stat.dim);
				stat.q = stat.queryVector[grid.center_id[0] * stat.n_col + grid.center_id[1]];
				stat.out_i = grid.center_id[0];
				stat.out_j = grid.center_id[1];
				GBF_iter(tree, stat);
			}

			grid_Queue.push(grid);
		}

		iter++;
		if (iter < stat.iteration)
			Divide(grid_Queue);
	}
}

void progressive_outResult(queue<Grid>& grid_Queue, statistics& stat)
{
	Grid grid;
	int g_size = grid_Queue.size();
	for (int g = 0; g < g_size; g++)
	{
		grid = grid_Queue.front();
		grid_Queue.pop();
		for (int x = grid.x_min_id; x <= grid.x_max_id; x++)
		{
			for (int y = grid.y_min_id; y <= grid.y_max_id; y++)
			{
				if (stat.out_matrix[x][y] < -99)
					stat.out_matrix[x][y] = stat.out_matrix[grid.center_id[0]][grid.center_id[1]];
			}
		}
	}
}