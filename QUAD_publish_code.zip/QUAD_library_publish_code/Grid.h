#pragma once
#ifndef GRID_H
#define GRID_H

#include "init_visual.h"
#include "alg_visual.h"

/*struct Grid
{
	double**Q_boundary;
	int row_id_left;
	int row_id_right;
	int col_id_left;
	int col_id_right;
};*/

void sequential_Grid_Preprocess(spatial_pos**& queryMatrix, statistics& stat, vector<Grid>& GridVector);
void sequential_Grid_Preprocess_Lipschitz(spatial_pos**& queryMatrix, statistics& stat, vector<Grid>& GridVector);
void Grid_refine(Node*curNode, statistics& stat, Tree& tree, double& f_cur_L, double& f_cur_U);


#endif