#include "Tree.h"

void Tree::update_Q_id()
{
	int Q_Node_id = 0;
	bound_pair b_pair;
	queue<Node*> Q_Node_Queue;
	Node*tempNode;

	Q_Node_Queue.push(rootNode);
	//List_Node.push_back(rootNode);

	while ((int)Q_Node_Queue.size() > 0)
	{
		tempNode = Q_Node_Queue.front();
		tempNode->Q_id = Q_Node_id;
		Q_boundList.push_back(b_pair);
		Q_filter.push_back(false);
		Q_Node_id++;

		Q_Node_Queue.pop();

		for (int c = 0; c < tempNode->childVector.size(); c++)
			Q_Node_Queue.push(tempNode->childVector[c]);
	}
}

void Tree::update_Q_filter(Node*node)
{
	Q_filter[node->Q_id] = true;
	for (int c = 0; c < node->childVector.size(); c++)
		update_Q_filter(node->childVector[c]);
}