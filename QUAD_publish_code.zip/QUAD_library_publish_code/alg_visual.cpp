#include "alg_visual.h"

inline void clearHeap(PQ& pq)
{
	int heapSize = (int)pq.size();
	for (int h = 0; h < heapSize; h++)
		pq.pop();
}

void GBF_iter(Tree& tree, statistics& stat)
{
	static PQ pq;
	pqNode pq_entry;
	Node*curNode;
	double L, U;
	double f_cur;
	double val_R;

	Node*rootNode = tree.rootNode;

	if (stat.method >= 1 && stat.method <= 2 || stat.method == 9 || (stat.method >= 16 && stat.method <= 18)) //Single query setting
	{
		L = rootNode->LB(stat.q, stat.dim, stat);
		U = rootNode->UB(stat.q, stat.dim, stat);
	}
	
	pq_entry.node = rootNode;
	pq_entry.node_L = L;
	pq_entry.node_U = U;
	pq_entry.discrepancy = U - L;

	pq.push(pq_entry);

	while (pq.size() != 0)
	{
		if (stat.q_type == 0) //epsilon-KVQ condition
		{
			if (validate_best(L, U, stat.epsilon, val_R) == true)
			{
				stat.out_matrix[stat.out_i][stat.out_j] = val_R;

				clearHeap(pq);
				return;
			}
		}
		if (stat.q_type == 1) //tau-KVQ condition
		{
			//binary classification
			if (L >= stat.tau_binary)
			{
				stat.out_matrix[stat.out_i][stat.out_j] = 1;
				clearHeap(pq);
				return;
			}
			if (U < stat.tau_binary)
			{
				stat.out_matrix[stat.out_i][stat.out_j] = -1;
				clearHeap(pq);
				return;
			}
		}

		pq_entry = pq.top();
		pq.pop();

		L = L - pq_entry.node_L;
		U = U - pq_entry.node_U;

		curNode = pq_entry.node;

		//leaf Node
		if ((int)curNode->idList.size() <= tree.leafCapacity)
		{
			f_cur = refinement(curNode, stat, tree);
			L = L + f_cur;
			U = U + f_cur;

			continue;
		}

		//Non-Leaf Node
		for (int c = 0; c < (int)curNode->childVector.size(); c++)
		{
			pq_entry.node_L = curNode->childVector[c]->LB(stat.q, stat.dim, stat);
			pq_entry.node_U = curNode->childVector[c]->UB(stat.q, stat.dim, stat);

			pq_entry.discrepancy = pq_entry.node_U - pq_entry.node_L;
			pq_entry.node = curNode->childVector[c];

			L = L + pq_entry.node_L;
			U = U + pq_entry.node_U;

			pq.push(pq_entry);
		}
	}

	if (stat.q_type == 0) //epsilon-KVQ condition
		stat.out_matrix[stat.out_i][stat.out_j] = L;
	else //tau-KVQ condition
	{
		if (L >= stat.tau_binary)
			stat.out_matrix[stat.out_i][stat.out_j] = 1;
		if (U < stat.tau_binary)
			stat.out_matrix[stat.out_i][stat.out_j] = -1;
	}
	
	clearHeap(pq);
}

void visual_Algorithm(statistics& stat)
{
	double**queryVector;
	spatial_pos**queryMatrix;
	vector<Grid> GridVector;
	double*alphaArray;
	queue<Grid> grid_Queue; //Used in progressive visualization
	double run_time;

	//preprocessing for query vector or matrix
	//***********************************************************************************//
	queries_preprocess(queryVector, queryMatrix, stat, 1);

	alphaArray = new double[stat.n]; //tKDC and KARL
	for (int i = 0; i < stat.n; i++)
		alphaArray[i] = 1;

	//Tree for P
	kdTree_adv kd_Tree(stat.dim, stat.featureVector, alphaArray, stat.leafCapacity);

	if (stat.method == 1 || stat.method == 16 || stat.method == 19) //tKDC (LB_MBR and UB_MBR)
		kd_Tree.rootNode = new kdNode();
	if (stat.method == 2 || stat.method == 17) //KARL (LB_KARL and UB_KARL)
		kd_Tree.rootNode = new kdLinearAugNode();
	if (stat.method == 9 || stat.method == 18) //LB_Quad UB_Quad
		kd_Tree.rootNode = new kdQuadAugNode();
	
	if (stat.method >= 1 && stat.method <= 19)
	{
		kd_Tree.build_kdTree_adv(stat);
		kd_Tree.updateAugment((kdNode*)kd_Tree.rootNode);
	}
	//***********************************************************************************//

	//Different algorithms
	auto start_s = chrono::high_resolution_clock::now();

	if (stat.method == 0) //SCAN method
		KDE_visual(queryVector, stat.featureVector, stat);

	if (stat.method == 1 || stat.method == 2 || stat.method == 9) //tKDC, KARL and QUAD
	{
		for (int i = 0; i < stat.n_row; i++)
		{
			for (int j = 0; j < stat.n_col; j++)
			{
				stat.qSquareNorm = computeSqNorm(queryVector[i*stat.n_col + j], stat.dim);
				stat.q = queryVector[i*stat.n_col + j];
				stat.out_i = i;
				stat.out_j = j;

				GBF_iter(kd_Tree, stat);
			}
		}
	}

	//Progressive Visualization (Anytime)
	if (stat.method >= 16 && stat.method <= 19)
	{
		stat.queryVector = queryVector;
		progressive_Evaluation_ANYTIME(grid_Queue, kd_Tree, stat);
		progressive_outResult(grid_Queue, stat);
	}
	
	auto end_s = chrono::high_resolution_clock::now();

	run_time = (chrono::duration_cast<chrono::nanoseconds>(end_s - start_s).count()) / 1000000000.0;

	std::cout << "method " << stat.method << ":" << run_time << endl;

	//save the output Matrix
	saveMatrix_toFile(stat);
}